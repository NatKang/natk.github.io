%build latex tables

%-----Coverage----------------------
matrix=[];
for n=2:7
    eval(sprintf('load coverage%d',n))
    eval(sprintf('matrix=[matrix; coverage%d];',n)) 
end

columnLabels = {'confidence level', '0.2', '0.3', '0.4', '0.5', '0.6', '0.7', '0.8' };
%matrix2latex_mod(matrix, 'coverage.tex', 'columnLabels', columnLabels, 'alignment', 'c', 'format', '%-6.4f');

xlswrite('coverage.xls',matrix)

%--------Comparison-----------------

matrix=[];
for n=2:7
    eval(sprintf('load comparison%d',n))
    eval(sprintf('matrix=[matrix; comparison%d];',n))
end

columnLabels={'$v$', 'QB', 'GPV',  'QB', 'GPV',  'QB', 'GPV', 'Std Err QB'};
%matrix2latex_mod(matrix, 'comparison24.tex', 'columnLabels', columnLabels, 'alignment', 'c', 'format', '%-6.4f');

xlswrite('comparison.xls',matrix)

fclose('all');



