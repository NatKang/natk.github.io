%----------Out for latex----------

fOut=sprintf('coverage%d.mat',n);
matrix=Coverage_QB/R;
matrix=[(1-alpha) matrix];
eval(sprintf('coverage%d=matrix;',n));
save(fOut,sprintf('coverage%d',n));


fOut=sprintf('comparison%d.mat',n);
matrix=[v0 [ mean(bias_qb,1); mean(bias_gpv,1)]' [ mean(mse_qb,1); mean(mse_gpv,1)]' [ mean(med_qb,1); mean(med_gpv,1)]' [mean(STD_QB,1)]'];
eval(sprintf('comparison%d=matrix;',n));
save(fOut,sprintf('comparison%d',n));

