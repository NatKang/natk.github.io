%this is the file bootstrap for running MC simulations
%it computes coverage probabilities of bootsrap CIs
%same number of bidders (n) is in all auctions
%this code uses the tri-weight kernel and its derivative

%distribution support [0,1]
%CDF F(v)=v^a;
%PDF f(v)=a*v^(a-1);
%bidding function B(v) = (1-1/(a*(n-1)+1))*v



clear all
tic;

%seed for random numbers generation
%rand('seed',42);
rand('seed',195066438);

%distribution
a=1/2
%number of bidders
n=7
%number of auctions
L=4200/n;
%number of simulations
R=300;
%number of bootstrap simulations
M=199;
%points where pdf of v is estimated
v0=[0.2 0.3 0.4 0.5 0.6 0.7 0.8]';



nL=n*L;
%bandwidth rate derivative
h_prime_rate=1.06*(nL)^(-1/7);
%bandwidth rate density
h_pdf_rate=1.06*(nL)^(-1/5);

%significance
alpha=[0.01 0.05 0.1]';


%true density
f0=a*v0.^(a-1);
%constant for sec order variance correction int(K^2)
K0=350/429;
%constant for variance calc int(dK^2)
K1=35/11; 




f_b=zeros(M, length(v0));
STD_b=zeros(M,length(v0));
T_b=zeros(M,length(v0));

COV_BT=zeros(length(alpha),length(v0));
COV_P=zeros(length(alpha),length(v0));

%stat ranks for lower and upper bounds
LR=(1-alpha/2)*(M+1);
UR=alpha/2*(M+1);

for r=1:R
    
    %generate bids----------------
    u=rand(nL,1);
    v=u.^(1/a);
    %compute bids
    bids=(1-1/(a*(n-1)+1))*v;
    
    
    %-------------------------------
    
    b=bids;
    %compute quantile based estimator and its standard error
    qbest4
    f_qb=fqb';
    STD_QB=V.^(1/2);
    
    %------------------BOOTSTRAP-------------------
    
    for m=1:M
        
        %generate bootstrap samples
        IND=randsample([1:nL]',nL,true);
        b=bids(IND,1);
        
        
        %compute bootstrap estr and it standard error
        qbest4;
        f_b(m,:)=fqb';
        STD_b(m,:)=V.^(1/2);
        %compute bootstrap t stat
        T_b(m,:)=(f_b(m,:)-f_qb)./STD_b(m,:);
    end
    
    %Bootstrap-t CIs
    T_b=sort(T_b,1);
    %crit val for lower bound
    LCV=T_b(LR,:);
    UCV=T_b(UR,:);
    L_BT=repmat(f_qb,length(alpha),1)-LCV.*repmat(STD_QB,length(alpha),1);
    U_BT=repmat(f_qb,length(alpha),1)-UCV.*repmat(STD_QB,length(alpha),1);
    IN_BT=(L_BT<=repmat(f0',length(alpha),1)).*(U_BT>=repmat(f0',length(alpha),1));
    COV_BT=COV_BT+IN_BT;

    %Bootstrap percentile CIs
    f_b=sort(f_b,1);
    %crit val for lower bound
    LP=f_b(UR,:);
    UP=f_b(LR,:);
    IN_P=(LP<=repmat(f0',length(alpha),1)).*(UP>=repmat(f0',length(alpha),1));
    COV_P=COV_P+IN_P;
   
    
   
end



disp('-----------Coverage Bootstrap t----------');
disp(COV_BT/R);

disp('-----------Coverage Percentile----------');
disp(COV_P/R);



%out4latex

toc/3600
