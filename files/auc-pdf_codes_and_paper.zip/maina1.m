%this is the main file for running MC simulations
%compares bias, MSE and med abs deviation of gpv and the quantile-based estimator
%it includes the definitions and collects the components
%same number of bidders (n) is in all auctions
%this code uses the tri-weight kernel and its derivative

%distribution support [0,1]
%CDF F(v)=v^a;
%PDF f(v)=a*v^(a-1);
%bidding function B(v) = (1-1/(a*(n-1)+1))*v



clear all

%seed for random numbers generation
%rand('seed',42);
rand('seed',195066438);

%distribution
a=2;
%number of bidders
n=7;
%number of auctions
L=4200/n;
%number of simulations
R=10000;
%points where pdf of v is estimated
v0=[0.2 0.3 0.4 0.5 0.6 0.7 0.8]';



nL=n*L;
%bandwidth rate derivative
h_prime_rate=1.06*(nL)^(-1/7);
%bandwidth rate density
h_pdf_rate=1.06*(nL)^(-1/5);

%significance
alpha=[0.01 0.05 0.1]';


%true density
f0=a*v0.^(a-1);
%constant for sec order variance correction int(K^2)
K0=350/429;
%constant for variance calc int(dK^2)
K1=35/11; 




f_qb=zeros(R, length(v0));
f_gpv=zeros(R, length(v0));
Coverage_QB=zeros(length(alpha),length(v0));
STD_QB=zeros(R,length(v0));

for r=1:R
    
    %generate bids----------------
    u=rand(nL,1);
    v=u.^(1/a);
    %compute bids
    b=(1-1/(a*(n-1)+1))*v;
    
    
    %-------------------------------
    
    %compute quantile based estimator
    qbest4
    f_qb(r,:)=fqb';
    
    %compute gpv estimator
    gpv3
    f_gpv(r,:)=fgpv';
    
    %coverage for QB estimator
    L_QB=repmat(fqb',length(alpha),1)-norminv(1-alpha/2)*V.^(1/2);
    U_QB=repmat(fqb',length(alpha),1)+norminv(1-alpha/2)*V.^(1/2);
    IN_QB=(L_QB<=repmat(f0',length(alpha),1)).*(U_QB>=repmat(f0',length(alpha),1));
    Coverage_QB=Coverage_QB+IN_QB;
    
    STD_QB(r,:)=V.^(1/2);
   
end

 

disp('-----------Coverage QB----------');
disp(Coverage_QB/R);

%compare MSEs
    mse_qb=(f_qb-repmat(f0',R,1)).^2;
    mse_gpv=(f_gpv-repmat(f0',R,1)).^2;
    
disp('--------------MSE---------------QB; GPV');
disp([ mean(mse_qb,1); mean(mse_gpv,1)])

%compare biases
bias_qb=(f_qb-repmat(f0',R,1));
bias_gpv=(f_gpv-repmat(f0',R,1));
disp('--------------Bias--------------QB; GPV');
disp([ mean(bias_qb,1); mean(bias_gpv,1)])

%compare Median abs deviations
med_qb=abs(f_qb-repmat(f0',R,1));
med_gpv=abs(f_gpv-repmat(f0',R,1));
disp('------------Med abs dev--------------QB; GPV');
disp([ mean(med_qb,1); mean(med_gpv,1)])

disp('---------------STD QB-----------');
disp([mean(STD_QB,1)])


%out4latex

