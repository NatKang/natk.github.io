%VECTORIZED VERSION OF GPV2

%computes vuong estimator
%given the ordered bids q
%n, L are defined in the main file
%bandwidth is computed in the file for quantile-based estimator

%the pdf of bids is estimated in the file computing the quantile based
%estimator
%the cdf of bids is in the same file as t

%compute fitted values
%they are the same as Q when we use q

%trimming
low=find(q<q(1)+h_pdf);
Q(low)=9999;
high=find(q>q(nL)-h_pdf);
Q(high)=9999;

w=bsxfun(@minus,Q,v0')/h_prime;
w=35/32*(1-w.^2).^3.*(w<=1).*(w>=-1); %tri-weight kernel
fgpv=(sum(w)/nL/h_prime)';
