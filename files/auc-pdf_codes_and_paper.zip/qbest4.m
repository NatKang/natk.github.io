%VECTORIZED VERSION OF QBEST2

%computes quantile based estimator 
%and its variance asy variance from bids data b
%same number of biders n in all auctions
%n is defined in the main file

%compute bandwidth derivative
h_prime=h_prime_rate*std(b);
%compute bandwidth pdf
h_pdf=h_pdf_rate*std(b);

%compute bids quantile function
q=sort(b);
%compute quantiles
t=[1:nL]'/nL;

%compute pdf of bids at all quantiles

ww=bsxfun(@minus,b,q')/h_pdf;
WW=find(abs(ww)<=1);
w=zeros(nL,nL);
w(WW)=35/32*(1-ww(WW).^2).^3; %tri-weight kernel

gq=sum(w)/nL/h_pdf;
gq=gq';

%estimate the Quantile function of values
%preliminary
Q=q+t./gq/(n-1);


%estimate F(v0);
%monotonization is same as taking
%first quantile that is greater or equal than v0 (minus one quant) on right
%and last on the left that is less or equal

im=zeros(length(v0),1);
P1=bsxfun(@gt,Q,v0');
P2=bsxfun(@le,Q,v0');
for j=1:length(v0)
    [row1,col1]=find(P1);
    [row2,col2]=find(P2);
    I1=find(col1==j);
    I2=find(col2==j);
    if v0(j)>=0.5;
        im(j,1)=min(row1(I1))-1;
    else im(j,1)=max(row2(I2));
    end
end
Fv0=t(im);
qFv0=q(im);
    
%estimate g(q(F(v0)))
ww=bsxfun(@minus,b,qFv0')/h_pdf;
WW=find(abs(ww)<=1);
w=zeros(nL,length(v0));
w(WW)=35/32*(1-ww(WW).^2).^3; %triweight kernel
gqFv0=(sum(w)/nL/h_pdf)';
    
%estimate the derivative of g at q(F(v0))
ww=bsxfun(@minus,b,qFv0')/h_prime;
WW=find(abs(ww)<=1);
w=zeros(nL,length(v0));
w(WW)=105/16*(1-ww(WW).^2).^2.*ww(WW); % -1 * deriv of tri-weight kernel
g1qFv0=(sum(w)/nL/h_prime^2)';
    
%compute pdf of v
temp=n/(n-1)*(gqFv0).^(-1)-1/(n-1)*(Fv0.*g1qFv0./gqFv0.^3);
fqb=(temp).^(-1);

%compute asy variance of pdf of v
V_g_1=K1*gqFv0;
V_f=(Fv0.^2).*(fqb.^4).*(V_g_1)./(gqFv0.^6)/(n-1)^2;
V_g_0=K0*gqFv0;
correction=h_prime.^2*(3*fqb./gqFv0-2*n*(fqb.^2)./(gqFv0.^2)/(n-1)).^2.*V_g_0;
V=(V_f+correction)/nL/h_prime^3;
V=V';
